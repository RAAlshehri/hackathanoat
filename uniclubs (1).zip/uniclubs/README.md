<h1 align="center">Welcome to Captivators club website</h1>
Joining a club or a society will enable you to connect to a peer group who shares similar interests as you.
You will get an insight into other countries culture, values, thinking process and views.<br>Being a part of a club or a society helps you to gain knowledge, skills, and experience.<br>You will undoubtedly learn new skills. In a diverse group, you will be able to experience personal growth. 
<br> 

## 🚀 Usage
In this club we show our talent into different different field. there are four club under the **CAPTIVATORS .**
1. CodeZen
2. Photopedia
3. ArtisticDots
4. SocializeLives

## 🤝 Contributing

Contributions, issues and feature requests are welcome.<br />
Feel free to check ! <br />

## Author

👤 **Shakti Singh**

- Github: [@shakti1590](https://github.com/shakti1590)

## Show your support

Please ⭐️ this repository if this project helped you!

## 📝 License

Copyright © 2022 [Shakti Singh](https://github.com/shakti1590).<br />

## Project Live demo
[Deployment Link](https://captivatorsclub.vercel.app).<br />
