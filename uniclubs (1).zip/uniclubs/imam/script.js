function facebook()
{
    alert("Don't waste time on Facebook!")
}
function twitter()
{
    alert("Don't waste time on Twitter!")
}
function instagram()
{
    alert("Don't waste time on Instagram!")
}